# plan_pomodoro_session_custom.R

plan_pomodoro_session_custom <- function(...) {
  task_name <- "Task"
  total_minutes <- 0
  focus_sessions_count <- 0
  short_break_count <- 0
  long_break_count <- 0
  focus_sessions_before_long_break <- 4
  current_posix <- Sys.time()
  output_lines <- character()
  
  args <- list(...)
  if (length(args) == 0) {
    cat("You didn't specify the Task name and Total time!\n")
    repeat {
      task_name <- trimws(readline(prompt = "Enter the task name: "))
      if (grepl("^[A-Za-z ]+$", task_name)) break
      cat("Task name should be a string.\n")
    }
    repeat {
      total_minutes <- as.numeric(trimws(readline(prompt = "Enter total minutes: ")))
      if (!is.na(total_minutes) && total_minutes > 0 && total_minutes <= 1440) break
      if (!is.na(total_minutes) && total_minutes > 1440) {
        cat("Total minutes can't be more than 1440 minutes\n")
      } else {
        cat("Total minutes must be a positive number.\n")
      }
    }
  } else if (length(args) == 1) {
    if (is.character(args[[1]])) {
      task_name <- trimws(args[[1]])
      repeat {
        total_minutes <- as.numeric(trimws(readline(prompt = "Enter total minutes: ")))
        if (!is.na(total_minutes) && total_minutes > 0 && total_minutes <= 1440) break
        if (!is.na(total_minutes) && total_minutes > 1440) {
          cat("Total minutes can't be more than 1440 minutes\n")
        } else {
          cat("Total minutes must be a positive number.\n")
        }
      }
    } else if (is.numeric(args[[1]])) {
      repeat {
        total_minutes <- args[[1]]
        if (!is.na(total_minutes) && total_minutes > 0 && total_minutes <= 1440) break
        if (!is.na(total_minutes) && total_minutes > 1440) {
          cat("Total minutes can't be more than 1440 minutes\n")
        } else {
          cat("Total minutes must be a positive number.\n")
        }
        total_minutes <- as.numeric(trimws(readline(prompt = "Enter total minutes: ")))
      }
      repeat {
        task_name <- trimws(readline(prompt = "Enter the task name: "))
        if (grepl("^[A-Za-z ]+$", task_name)) break
        cat("Task name should be a string.\n")
      }
    } else {
      stop("Invalid argument type. Provide a character (task name) or numeric (total minutes).")
    }
  } else if (length(args) == 2) {
    if (is.character(args[[1]]) && is.numeric(args[[2]])) {
      task_name <- trimws(args[[1]])
      total_minutes <- args[[2]]
    } else if (is.numeric(args[[1]]) && is.character(args[[2]])) {
      total_minutes <- args[[1]]
      task_name <- trimws(args[[2]])
    } else {
      stop("Invalid argument types. Provide task name (text) and total time (number).")
    }
    repeat {
      if (!is.na(total_minutes) && total_minutes > 0 && total_minutes <= 1440) break
      if (!is.na(total_minutes) && total_minutes > 1440) {
        cat("Total minutes can't be more than 1440 minutes\n")
      } else {
        cat("Total minutes must be a positive number.\n")
      }
      total_minutes <- as.numeric(trimws(readline(prompt = "Enter total minutes: ")))
    }
  } else {
    stop("Function takes up to 2 arguments: Task name and Total time (mins).")
  }
  
  # Get custom duration with validation
  repeat {
    focus_duration <- as.numeric(trimws(readline(prompt = "Custom focus session duration: ")))
    if (!is.na(focus_duration) && focus_duration >= 20 && focus_duration <= 35) break
    cat("Focus session duration should be between 20 mins and 35 mins\n")
  }
  
  repeat {
    short_break_duration <- as.numeric(trimws(readline(prompt = "Custom short break duration: ")))
    if (!is.na(short_break_duration) && short_break_duration >= 3 && short_break_duration <= 8) break
    cat("Short break duration should be between 3 mins and 8 mins\n")
  }
  
  repeat {
    long_break_duration <- as.numeric(trimws(readline(prompt = "Custom long break duration: ")))
    if (!is.na(long_break_duration) && long_break_duration >= 12 && long_break_duration <= 20) break
    cat("Long break duration should be between 12 mins and 20 mins\n")
  }
  
  intro <- sprintf("Your %d-minutes (%.1f hours) Custom Pomodoro '%s' Schedule [Starting at %s]:\n",
                   total_minutes,
                   total_minutes / 60,
                   task_name,
                   format(current_posix, "%I:%M %p"))
  cat(intro, "\n")
  output_lines <- c(output_lines, intro)
  
  while (total_minutes >= focus_duration) {
    focus_sessions_count <- focus_sessions_count + 1
    
    start_time <- format(current_posix, "%I:%M %p")
    current_posix <- current_posix + focus_duration * 60
    end_time <- format(current_posix, "%I:%M %p")
    total_minutes <- total_minutes - focus_duration
    line <- sprintf("[%s - %s] Focus Session %d (%d min)", start_time, end_time, focus_sessions_count, focus_duration)
    cat(line, "\n")
    output_lines <- c(output_lines, line)
    
    if (total_minutes < short_break_duration) break
    
    if (focus_sessions_count %% focus_sessions_before_long_break == 0 && total_minutes >= long_break_duration) {
      long_break_count <- long_break_count + 1
      start_time <- format(current_posix, "%I:%M %p")
      current_posix <- current_posix + long_break_duration * 60
      end_time <- format(current_posix, "%I:%M %p")
      total_minutes <- total_minutes - long_break_duration
      line <- sprintf("[%s - %s] Long Break! %d (%d min)", start_time, end_time, long_break_count, long_break_duration)
    } else if (total_minutes >= short_break_duration) {
      short_break_count <- short_break_count + 1
      start_time <- format(current_posix, "%I:%M %p")
      current_posix <- current_posix + short_break_duration * 60
      end_time <- format(current_posix, "%I:%M %p")
      total_minutes <- total_minutes - short_break_duration
      line <- sprintf("[%s - %s] Short Break %d (%d min)", start_time, end_time, short_break_count, short_break_duration)
    }
    cat(line, "\n")
    output_lines <- c(output_lines, line)
    
    if (total_minutes >= focus_duration) {
      line <- sprintf("Remaining time: %d min", total_minutes)
    } else if (total_minutes >= 10) {
      start_time <- format(current_posix, "%I:%M %p")
      current_posix <- current_posix + total_minutes * 60
      end_time <- format(current_posix, "%I:%M %p")
      line <- sprintf("\n[%s - %s] Last Focus Session (%d min)", start_time, end_time, total_minutes)
      total_minutes <- 0
    } else {
      line <- sprintf("Only %d minutes left. Not enough for another session.", total_minutes)
    }
    cat(line, "\n\n")
    output_lines <- c(output_lines, line, "")
  }
  
  summary <- sprintf("---------------\n SUMMARY:\n- Focus Sessions: %d\n- Short Breaks: %d\n- Long Breaks: %d\n---------------",
                     focus_sessions_count, short_break_count, long_break_count)
  cat(summary, "\n")
  output_lines <- c(output_lines, summary)
  
  writeLines(output_lines, "schedule.txt")
  cat("Schedule also saved to 'schedule.txt'\n")
}
