pomodoro_productive_ratio <- function(file_name = NULL) {
  # Prompt user if no file name is provided
  if (is.null(file_name)) {
    file_name <- trimws(readline(prompt = "Enter the schedule file name (e.g., schedule.txt): "))
  }
  
  # Validate file exists
  if (!file.exists(file_name)) {
    cat("File does not exist. Please check the file name and try again.\n")
    return(invisible(NULL))
  }
  
  # Read file contents
  lines <- readLines(file_name)
  
  # Basic check: must contain Focus Session lines
  if (!any(grepl("Focus Session", lines))) {
    cat("The file does not appear to be a valid Pomodoro schedule file.\n")
    return(invisible(NULL))
  }
  
  # Initialize totals
  total_focus_time <- 0
  total_break_time <- 0
  
  # Loop through lines and calculate duration
  for (line in lines) {
    if (grepl("Focus Session", line) && grepl("\\(\\d+ min\\)", line)) {
      duration <- as.numeric(sub(".*\\((\\d+) min\\).*", "\\1", line))
      if (!is.na(duration)) {
        total_focus_time <- total_focus_time + duration
      }
    } else if ((grepl("Short Break", line) || grepl("Long Break", line)) &&
               grepl("\\(\\d+ min\\)", line)) {
      duration <- as.numeric(sub(".*\\((\\d+) min\\).*", "\\1", line))
      if (!is.na(duration)) {
        total_break_time <- total_break_time + duration
      }
    }
  }
  
  total_time <- total_focus_time + total_break_time
  
  if (total_time == 0) {
    cat("No focus or break durations found in the file.\n")
    return(invisible(NULL))
  }
  
  # Calculate productivity ratio
  productivity_ratio <- (total_focus_time / total_time) * 100
  
  # Format result
  report <- c(
    "----- Productivity Report -----",
    sprintf("Total Focus Time  : %d minutes", total_focus_time),
    sprintf("Total Break Time  : %d minutes", total_break_time),
    sprintf("Productivity Ratio: %.2f%%", productivity_ratio),
    "-------------------------------"
  )
  
  # Print report
  cat(paste0(report, collapse = "\n"), "\n")
  
  # Save to file
  writeLines(report, "productivity_report.txt")
  cat("Report saved to 'productivity_report.txt'\n")
}
