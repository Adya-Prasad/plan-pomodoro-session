library(testthat)

# Check function runs correctly with valid inputs
test_that("Plan pomodoro session function runs with character and numeric args", {
  expect_output(plan_pomodoro_session("Writing", 60), "Focus Session 1")
  expect_true(file.exists("schedule.txt"))
})


# Check that schedule.txt is generated and contains expected lines
test_that("Output file contains expected text", {
  plan_pomodoro_session("Writing", 60)
  lines <- readLines("schedule.txt")
  expect_true(any(grepl("Focus Session", lines)))
  expect_true(any(grepl("SUMMARY", lines)))
})

# Test error handling on invalid inputs
test_that("Error when wrong argument types are passed", {
  expect_error(plan_pomodoro_session(TRUE, 30), 
               regexp = "Invalid argument types")
  expect_error(plan_pomodoro_session("Task", "sixty"), 
               regexp = "Invalid argument types")
})

