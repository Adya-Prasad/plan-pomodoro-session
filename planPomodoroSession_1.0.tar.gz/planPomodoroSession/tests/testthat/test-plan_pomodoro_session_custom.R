library(testthat)

# Check function runs correctly with valid inputs
test_that("plan_pomodoro_session_custom runs with character and numeric args", {
  skip_if(interactive(), "Interactive input required, skipping in non-interactive test")
  
  expect_output(plan_pomodoro_session_custom("Reading", 60), "Focus Session 1")
  expect_true(file.exists("schedule.txt"))
})

# Check that schedule.txt is generated and contains expected schedule lines
test_that("Output file from plan_pomodoro_session_custom contains expected sections", {
  skip_if(interactive(), "Interactive input required, skipping in non-interactive test")
  
  plan_pomodoro_session_custom("Reading", 60)
  lines <- readLines("schedule.txt")
  expect_true(any(grepl("Focus Session", lines)))
  expect_true(any(grepl("SUMMARY", lines)))
})

