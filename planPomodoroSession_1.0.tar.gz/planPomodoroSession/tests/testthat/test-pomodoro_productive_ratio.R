library(testthat)

test_that("Correctly processes a valid pomodoro schedule file", {
  # Create a mock valid schedule file
  schedule_lines <- c(
    "Focus Session 1 (25 min): Task",
    "Short Break 1 (5 min)",
    "Focus Session 2 (25 min): Task",
    "Long Break (15 min)",
    "SUMMARY:"
  )
  writeLines(schedule_lines, "test_schedule_valid.txt")
  
  expect_output(pomodoro_productive_ratio("test_schedule_valid.txt"), "Productivity Ratio")
  expect_true(file.exists("productivity_report.txt"))
  
  # Clean up
  file.remove("test_schedule_valid.txt")
  file.remove("productivity_report.txt")
})

test_that("Handles missing file with appropriate message", {
  expect_output(pomodoro_productive_ratio("nonexistent.txt"), 
                "File does not exist")
})

test_that("Handles invalid schedule file with no focus sessions", {
  # Create invalid schedule file
  writeLines(c("Just some random notes", "No focus session here"), "invalid_schedule.txt")
  
  expect_output(pomodoro_productive_ratio("invalid_schedule.txt"), 
                "does not appear to be a valid Pomodoro schedule file")
  
  file.remove("invalid_schedule.txt")
})

test_that("Handles file with zero durations", {
  # File with no durations
  writeLines(c("Focus Session 1: Task", "Short Break"), "zero_duration_schedule.txt")
  
  expect_output(pomodoro_productive_ratio("zero_duration_schedule.txt"),
                "No focus or break durations found")
  
  file.remove("zero_duration_schedule.txt")
})
